//Ralphilou Tatoy
#include <iostream>
#include "headerfile.h"
using namespace std;
void header1()
{
    cout << "This function is void header1() and it returns void/nothing" << endl;

}
int header2(int thre, int fou)
{
    cout << "This function is int header2(int three, int four) and returns int"<< endl;
    

}
char header3(char fiv)
{
    cout << "This function is char header3(char five) and it returns char" << endl;
    
}
float header4(double si, float seve)
{
    cout << "This function is float header4(double six, float seven) and it returns float" <<endl;
    
}
// int main()
// {

// }



