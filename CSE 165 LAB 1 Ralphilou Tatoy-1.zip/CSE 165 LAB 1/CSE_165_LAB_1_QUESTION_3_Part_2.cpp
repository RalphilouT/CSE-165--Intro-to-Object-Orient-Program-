//Ralphilou Tatoy
#include <iostream>
#include "headerfile.h"
using namespace std;
int main(int argc,char **argv){
    header1();
    header2(3, 4);
    header3('H');
    header4(6.0, 7.2);
    return 0;
}