#ifndef headerfile_h
#define headerfile_h
void header1();

int header2(int three, int four);

char header3(char five);

float header4(double six, float seven);

#endif